package com.capg.sixtwo;

import java.util.Scanner;

import com.capg.sixone.BlankNameException;

public class Bank {
public static void main(String[] args) {
	SavingsAccount a1 = new SavingsAccount();
	a1.setAccNum(111111);
	a1.setName("Sushil");
	System.out.println("Enter the age of the person in savings account: ");
	Scanner sc = new Scanner(System.in);
	int age1 = sc.nextInt();
	
	if(age1 < 15) {
		try {
			throw new AgeLimitException();
		}catch( AgeLimitException e){
			System.err.println("age should be greater than 15");
			System.exit(0);
		}
	}
	else 
	{
		a1.setAge(age1);
	}
	
	a1.setBalance(2000);
	System.out.println(a1.toString());
	
	CurrentAccount a2 = new CurrentAccount();
	a2.setAccNum(222222);
	a2.setName("Suraj");
	System.out.println("Enter the age of the person in current account: ");
	Scanner scr = new Scanner(System.in);
	int age2 = scr.nextInt();
	a2.setAge(age2);
	if(age2 < 15) {
		try {
			throw new AgeLimitException();
		}catch( AgeLimitException e){
			System.err.println("age should be greater than 15");
			System.exit(0);
		}
	}
	else {
		
	a2.setBalance(12000);
}
	System.out.println(a2.toString());
	
	a1.Withdraw(1000);
	a2.Withdraw(12000);
	
	
	
}

}
