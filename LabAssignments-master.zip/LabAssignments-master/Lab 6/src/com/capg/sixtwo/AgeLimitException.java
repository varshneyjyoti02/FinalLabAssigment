package com.capg.sixtwo;

public class AgeLimitException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
