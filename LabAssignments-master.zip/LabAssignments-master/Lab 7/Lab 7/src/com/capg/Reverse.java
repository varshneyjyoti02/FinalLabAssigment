package com.capg;

import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class Reverse {
	
	public static void main(String[] args) {
	 int i;	 
	 ArrayList<String> al = new ArrayList<String>();
	 int Arr[] = {12,52,48,67};
	 int l = Arr.length;
	 String s[] = new String[l];
	 for( i= 0; i<l;i++) {
       s[i] = String.valueOf(Arr[i]);
	  }
	   i=0;
	   String r[]  = new String[l];
	   for(String word:s)
	   {
		   StringBuilder str = new StringBuilder(word);
		   r[i]= str.reverse().toString();
		   al.add(r[i]);
		   i++;
	   }
	   
	   	   
	  
	Collections.sort(al);
	System.out.println(al);
	   
	  
	  
	
	}


}


