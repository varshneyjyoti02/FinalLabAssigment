package com.capg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Arraylist {
	public static void main(String[] args) {
	String a[] = {"sushil","suraj","chirag"};
	Elements s = new Elements();
	s.getstrings(a);
	}
}

class Elements{
	void getstrings(String[] a) {
		List<String> list = new ArrayList<String>();
		for(String i : a)
		list.add(i);
	Collections.sort(list);
	System.out.println(list);
	
	}
}

