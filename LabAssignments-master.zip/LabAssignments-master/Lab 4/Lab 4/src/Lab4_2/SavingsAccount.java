package Lab4_2;

public class SavingsAccount extends Account {
       public void Withdraw(double Amount) {
  	    if(withdrawAccess(Amount)) {
  	         balance -= Amount;
  	 System.out.println("Updated Balance for SavingsAccount:"+getAccNum()+"is"+balance);
  	 System.out.println("");
  	    }
  	    else
  	    {
  	    	System.out.println("pls maintain minimum balance");
  	    	System.out.println("");
  	    }
       }


  	   
 public boolean withdrawAccess(double Amount) {
	 final double MinBalance = 500;
 
   if((balance - Amount) <= MinBalance)
   {
	   return false;
	  }
   else
   {
	   return true;
   }
	   
   }
}