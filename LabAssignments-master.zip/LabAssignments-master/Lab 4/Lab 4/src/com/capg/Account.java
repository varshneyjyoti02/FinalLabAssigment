package com.capg;

public class Account {
	long accNum;
	double balance;
	Person accHolder;
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

public void Deposit(double Amount) {
	balance += Amount;
	System.out.println("Updated Balance for Acc:no"+getAccNum() + "is" + getBalance() );
}
public void withdraw(double Amount) {
	if((balance - Amount)<500) 
	{
		System.out.println("Please Maintain minimum balance");
	}
	else
	{
		balance -= Amount;
		System.out.println("Updated Balance for Acc:no"+getAccNum() + "is" +getBalance() );
	}
	balance -= Amount;
	System.out.println("Updated Balance for Acc no:"+getAccNum() );
}
@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance + "]";
}

}
