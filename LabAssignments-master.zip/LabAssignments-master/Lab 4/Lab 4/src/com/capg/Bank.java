package com.capg;

import java.util.Random;

public class Bank {
public static void main(String[] args) {
	Random Rand = new Random();
	
	Person personOne = new Person();
	personOne.setAccHolder(personOne);
	personOne.setBalance(2000);
	personOne.setName("Smith");
	personOne.setAge(20);
	personOne.setAccNum(Rand.nextInt());
	System.out.println(personOne.toString());
	System.out.println(" ");
	
	Person personTwo = new Person();
	personTwo.setAccHolder(personTwo);
	personTwo.setBalance(3000);
	personTwo.setName("Kathy");
	personTwo.setAge(20);
	personTwo.setAccNum(Rand.nextInt());
	System.out.println(personTwo.toString());
	System.out.println(" ");
	
	personOne.Deposit(2000);
	personTwo.withdraw(2000);
	
}
}
