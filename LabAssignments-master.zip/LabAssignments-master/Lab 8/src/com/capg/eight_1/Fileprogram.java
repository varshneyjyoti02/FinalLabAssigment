package com.capg.eight_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Fileprogram {

public static void main(String[] args) {
	FileInputStream fis;
	FileOutputStream fos;
	try{
		fis = new  FileInputStream("D:\\sushil\\Lab8\\src\\source.txt");
		fos = new  FileOutputStream("D:\\sushil\\Lab8\\src\\target.txt");
	    CopyDatathread obj =new CopyDatathread(fis,fos);
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
	}
}
	
}
