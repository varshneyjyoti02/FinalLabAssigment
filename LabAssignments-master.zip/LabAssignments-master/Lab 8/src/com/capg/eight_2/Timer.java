package com.capg.eight_2;

public class Timer implements Runnable {
  static int count = 0;
public static void main(String[] args) {
	Timer obj = new Timer();
	Thread t = new Thread(obj);t.start();
	
}
	public void run() {
		while(true) {
			try {
				System.out.println(System.currentTimeMillis());
				Thread.sleep(1000);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
